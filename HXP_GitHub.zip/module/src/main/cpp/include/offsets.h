#pragma once
// ================================================================
//  HXP Offsets - Play Together VNG v2.27.1.212435
//  Tự động điền từ dump.cs
// ================================================================

namespace Offset {
    // Player
    uintptr_t SetArrivalPosition   = 0x3c20080;
    uintptr_t SetVisible           = 0x3c3bf38;
    uintptr_t SetGravity           = 0x3c4526c;
    uintptr_t SetGravityJump       = 0x3c3f984;
    uintptr_t ReadyComplete        = 0x3c3fdd4;
    uintptr_t CheckPoint           = 0x3c38440;
    uintptr_t SetTransformPlayer   = 0x4629890;
    uintptr_t SetMovement          = 0x462989c;
    uintptr_t SetToReady           = 0x3c40308;
    uintptr_t get_IsInvincible     = 0x4626914;
    uintptr_t set_IsInvincible     = 0x462690c;
    uintptr_t DropTheLoser         = 0x4b0dc30;
    uintptr_t DropTheUser          = 0x4b0dcc4;
    uintptr_t UpdateToRank         = 0x4b14fcc;
    uintptr_t NpcReadyComplete     = 0x4b144a8;
    uintptr_t OnNotifyLeave        = 0x4b14718;

    // Fields (offset từ instance pointer)
    uintptr_t F_MoveSpeed          = 0x20;
    uintptr_t F_IsInvincible       = 0x66;
    uintptr_t F_MoveLengthRate     = 0x4f0;
    uintptr_t F_FlyMoveDelta       = 0x4f4;
    uintptr_t F_IsCanMove          = 0x4a0;
    uintptr_t F_AlienMoveSpeed     = 0x170;
}

// ================================================================
//  HXP Mod Menu v2.0 - Play Together VNG
//  Build via GitHub Actions
// ================================================================
#include <jni.h>
#include <android/log.h>
#include <unistd.h>
#include <thread>
#include <dlfcn.h>
#include "zygisk.hpp"
#include "include/offsets.h"
#include "dobby.h"
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>

#define TAG "HXP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── STATES ────────────────────────────────────────────────────
namespace State {
    bool menuOpen       = false;
    bool imguiInit      = false;
    int  currentTab     = 0;

    // Main Tab
    bool charNoSleep    = false;
    bool skipItemInfo   = false;
    bool autoOpenItem   = false;
    bool skipAskDialog  = false;
    bool skipNpcDialog  = false;
    bool freezeWeather  = false;
    bool removeRain     = false;
    bool hideOthers     = false;
    bool showCrown      = false;
    bool showPlus       = false;
    int  nameTagType    = 0;
    char coupleName[64] = "";
    float actionSpeed   = 1.0f;

    // Minigame Tab
    float speedVal      = 0.0f;
    float jumpHighVal   = 0.0f;
    float jumpFarVal    = 0.0f;
    bool walkOnAir      = false;
    bool infiniteJump   = false;
    bool noGravity      = false;
    bool noClip         = false;
    bool godV1          = false;
    bool godV2          = false;
    bool moveUp         = false;
    bool moveDown       = false;
    bool moveLeft       = false;
    bool moveRight      = false;
    float moveSpd       = 5.0f;
    bool playerDropV1   = false;
    bool playerDropV2   = false;
    bool autoVeDich     = false;
    bool autoHammer     = false;
    bool ghostHammer    = false;
    bool chasePlayer    = false;
    bool autoReadyParty = false;
    bool zombieBite     = false;
    bool towerGod       = false;

    // One-shot
    bool nr_veDich      = false;
    bool nr_nhanHang    = false;
    bool nr_thoatTran   = false;
    bool nr_walkOnAir   = false;
    bool nr_noClip      = false;
    bool nr_towerFinish = false;
    int  targetIdx      = 0;
}

// ── HELPERS ───────────────────────────────────────────────────
uintptr_t getBase(const char* lib) {
    char line[512]; FILE* fp = fopen("/proc/self/maps","r");
    if (!fp) return 0;
    while (fgets(line,sizeof(line),fp)) {
        if (strstr(line,lib)) { fclose(fp); return (uintptr_t)strtoul(line,nullptr,16); }
    }
    fclose(fp); return 0;
}

void SectionHdr(const char* label) {
    ImGui::Spacing();
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.4f,0.7f,1,1));
    ImGui::Separator();
    ImGui::Text(" %s", label);
    ImGui::Separator();
    ImGui::PopStyleColor();
    ImGui::Spacing();
}

bool FeatCheck(const char* label, bool* v) {
    if (*v) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.3f,0.85f,1,1));
    bool c = ImGui::Checkbox(label, v);
    if (*v) ImGui::PopStyleColor();
    return c;
}

bool OneShot(const char* label, float w = -1) {
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.13f,0.22f,0.45f,1));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.22f,0.40f,0.70f,1));
    bool p = ImGui::Button(label, ImVec2(w < 0 ? ImGui::GetContentRegionAvail().x : w, 28));
    ImGui::PopStyleColor(2);
    return p;
}

// ── DRAW TABS ─────────────────────────────────────────────────
void DrawMain() {
    SectionHdr("NHÂN VẬT");
    FeatCheck("Nhân Vật Ko Ngủ",     &State::charNoSleep);
    if (OneShot("Hoàn Thành Nhiệm Vụ NPC")) { /* TODO */ }
    ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x * 0.6f);
    ImGui::SliderFloat("Tăng Tốc Hành Động", &State::actionSpeed, 1.0f, 10.0f, "%.1fx");
    ImGui::PopItemWidth();

    if (ImGui::CollapsingHeader("  Hộp Thoại & Môi Trường")) {
        FeatCheck("Bỏ Qua Thông Tin Vật Phẩm", &State::skipItemInfo);
        FeatCheck("Tự Động Mở Vật Phẩm",       &State::autoOpenItem);
        FeatCheck("Bỏ Qua Hộp Thoại Hỏi",      &State::skipAskDialog);
        FeatCheck("Bỏ Qua NPC Nói",             &State::skipNpcDialog);
        ImGui::Separator();
        FeatCheck("Đóng Băng Trời",  &State::freezeWeather);
        FeatCheck("Xóa Mưa, Tuyết", &State::removeRain);
    }

    if (ImGui::CollapsingHeader("  Tên & Người Chơi")) {
        ImGui::TextDisabled("[.n <tên> | .mt <map> | .hide]");
        ImGui::Separator();
        FeatCheck("Ẩn Người Chơi Khác", &State::hideOthers);
        FeatCheck("Tên Tím (Plus Fake)", &State::showPlus);
        FeatCheck("Vương Miện",          &State::showCrown);
        const char* tags[] = {"Không","Partner","VNG Official","Couple","Bạn Bè"};
        ImGui::PushItemWidth(-1);
        ImGui::Combo("Bảng Tên##tag", &State::nameTagType, tags, 5);
        ImGui::PopItemWidth();
        if (State::nameTagType == 3)
            ImGui::InputText("Tên CP", State::coupleName, 64);
    }
}

void DrawMinigame() {
    if (ImGui::CollapsingHeader("  Player Modifiers", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x * 0.6f);
        ImGui::SliderFloat("Chạy Nhanh",  &State::speedVal,    0.0f, 15.0f, "%.1fx");
        ImGui::SliderFloat("Nhảy Cao",    &State::jumpHighVal, 0.0f, 15.0f, "%.1fx");
        ImGui::SliderFloat("Nhảy Xa",     &State::jumpFarVal,  0.0f, 15.0f, "%.1fx");
        ImGui::PopItemWidth();
        ImGui::Spacing();
        float hw = (ImGui::GetContentRegionAvail().x-8)*0.5f;
        FeatCheck("Đi Trên Ko",    &State::walkOnAir);
        ImGui::SameLine(hw+8);
        if (ImGui::Button("NR Trên Ko", ImVec2(hw,24))) State::nr_walkOnAir=true;
        FeatCheck("Nhảy Vô Hạn",  &State::infiniteJump);
        FeatCheck("Ko Trọng Lực", &State::noGravity);
        FeatCheck("NoClip",        &State::noClip);
        ImGui::SameLine(hw+8);
        if (ImGui::Button("NR NoClip", ImVec2(hw,24))) State::nr_noClip=true;
        FeatCheck("Bất Tử V1",    &State::godV1);
        FeatCheck("Bất Tử V2",    &State::godV2);
    }

    if (ImGui::CollapsingHeader("  Game Party!")) {
        SectionHdr("MỌI NGƯỜI RƠI TỰ DO");
        float bw = (ImGui::GetContentRegionAvail().x-8)*0.5f;
        if (ImGui::Button("Trên Trái",  ImVec2(bw,28))) { State::moveUp=State::moveLeft=true; State::moveDown=State::moveRight=false; }
        ImGui::SameLine();
        if (ImGui::Button("Trên Phải", ImVec2(bw,28))) { State::moveUp=State::moveRight=true; State::moveDown=State::moveLeft=false; }
        if (ImGui::Button("Dưới Trái", ImVec2(bw,28))) { State::moveDown=State::moveLeft=true; State::moveUp=State::moveRight=false; }
        ImGui::SameLine();
        if (ImGui::Button("Dưới Phải",ImVec2(bw,28))) { State::moveDown=State::moveRight=true; State::moveUp=State::moveLeft=false; }
        if (ImGui::Button("STOP",ImVec2(-1,24))) { State::moveUp=State::moveDown=State::moveLeft=State::moveRight=false; }
        ImGui::PushItemWidth(120);
        ImGui::SliderFloat("Speed##mv", &State::moveSpd, 1.0f, 30.0f);
        ImGui::PopItemWidth();
        FeatCheck("Player Drop V1", &State::playerDropV1);
        FeatCheck("Player Drop V2", &State::playerDropV2);

        SectionHdr("VỀ ĐÍCH TẤT CẢ MAP");
        if (OneShot("Về Đích"))           State::nr_veDich   = true;
        if (OneShot("Nhận Hạng Về Đích")) State::nr_nhanHang = true;
        FeatCheck("Auto Về Đích",         &State::autoVeDich);

        SectionHdr("MAP RIÊNG BIỆT");
        FeatCheck("Auto Đập Búa",  &State::autoHammer);
        FeatCheck("Hù Map Búa",    &State::ghostHammer);

        SectionHdr("NGƯỜI CHƠI");
        FeatCheck("Dí Người Chơi",      &State::chasePlayer);
        if (ImGui::Button("Đổi Người +", ImVec2(bw,28))) State::targetIdx++;
        ImGui::SameLine();
        if (ImGui::Button("Đổi Người -", ImVec2(bw,28))) State::targetIdx--;

        SectionHdr("TÍNH NĂNG BỔ SUNG");
        FeatCheck("Tự Ready Tiệc Nhà",  &State::autoReadyParty);
        if (OneShot("Thoát Trận")) State::nr_thoatTran = true;
    }

    if (ImGui::CollapsingHeader("  Zombie Virus")) {
        FeatCheck("Cắn Người Trốn Từ Xa", &State::zombieBite);
    }

    if (ImGui::CollapsingHeader("  Infinity Tower")) {
        ImGui::TextColored(ImVec4(1,0.8f,0.3f,1),"Doi 15s sau khi ve dich!");
        FeatCheck("Bất Tử", &State::towerGod);
        if (OneShot("Lấy Hạng Về Đích")) State::nr_towerFinish = true;
    }
}

// ── RENDER ────────────────────────────────────────────────────
void SetupStyle() {
    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding=6; s.FrameRounding=4; s.WindowBorderSize=1.5f;
    s.Colors[ImGuiCol_WindowBg]      = ImVec4(0.05f,0.07f,0.12f,0.95f);
    s.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.13f,0.20f,0.38f,1);
    s.Colors[ImGuiCol_Button]        = ImVec4(0.13f,0.20f,0.38f,1);
    s.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.20f,0.35f,0.60f,1);
    s.Colors[ImGuiCol_CheckMark]     = ImVec4(0.30f,0.75f,1.00f,1);
    s.Colors[ImGuiCol_SliderGrab]    = ImVec4(0.30f,0.55f,0.90f,1);
    s.Colors[ImGuiCol_FrameBg]       = ImVec4(0.10f,0.13f,0.22f,1);
    s.Colors[ImGuiCol_Header]        = ImVec4(0.13f,0.20f,0.38f,1);
    s.Colors[ImGuiCol_Tab]           = ImVec4(0.10f,0.15f,0.28f,1);
    s.Colors[ImGuiCol_TabActive]     = ImVec4(0.17f,0.28f,0.50f,1);
}

typedef EGLBoolean (*eglSwap_t)(EGLDisplay,EGLSurface);
eglSwap_t orig_eglSwap = nullptr;

EGLBoolean hook_eglSwap(EGLDisplay dpy, EGLSurface surf) {
    if (!State::imguiInit) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2(1080,1920);
        io.IniFilename = nullptr;
        SetupStyle();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        State::imguiInit = true;
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    // Toggle button
    ImGui::SetNextWindowPos(ImVec2(5,5), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(52,52), ImGuiCond_Always);
    ImGui::Begin("##btn", nullptr,
        ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|
        ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoBackground);
    ImGui::PushStyleColor(ImGuiCol_Button,
        State::menuOpen ? ImVec4(0.2f,0.5f,0.9f,0.9f) : ImVec4(0.08f,0.12f,0.22f,0.9f));
    if (ImGui::Button("HXP", ImVec2(44,44))) State::menuOpen = !State::menuOpen;
    ImGui::PopStyleColor();
    ImGui::End();

    if (State::menuOpen) {
        ImGui::SetNextWindowPos(ImVec2(60,5), ImGuiCond_Once);
        ImGui::SetNextWindowSize(ImVec2(340,560), ImGuiCond_Once);
        ImGui::Begin("HXP Mod Menu", &State::menuOpen);

        const char* tabs[] = {"Mai...","Coll...","Mini...","ESP","Adv...","Info"};
        if (ImGui::BeginTabBar("##tabs")) {
            if (ImGui::BeginTabItem("Main"))     { DrawMain();     ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Minigame")) { DrawMinigame(); ImGui::EndTabItem(); }
            ImGui::EndTabBar();
        }
        ImGui::End();
    }

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return orig_eglSwap(dpy, surf);
}

// ── HOOKS ─────────────────────────────────────────────────────
void InstallHooks() {
    uintptr_t base = getBase("libil2cpp.so");
    if (!base) return;
    LOGI("Base: 0x%lx", base);

    void* egl = dlopen("libEGL.so", RTLD_NOW);
    if (egl) {
        void* swap = dlsym(egl, "eglSwapBuffers");
        if (swap) DobbyHook(swap, (void*)hook_eglSwap, (void**)&orig_eglSwap);
    }
    LOGI("Hooks installed");
}

// ── ZYGISK ────────────────────────────────────────────────────
class HXPModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api* api, JNIEnv* env) override {
        this->api = api; this->env = env;
    }
    void postAppSpecialize(const zygisk::AppSpecializeArgs* args) override {
        const char* name = env->GetStringUTFChars(args->nice_name, nullptr);
        bool hit = name && (strstr(name,"haegin") || strstr(name,"playtogether") || strstr(name,"vng.play"));
        if (name) env->ReleaseStringUTFChars(args->nice_name, name);
        if (!hit) return;
        LOGI("Target found! Starting HXP...");
        std::thread([]{ sleep(3); InstallHooks(); }).detach();
    }
private:
    zygisk::Api* api; JNIEnv* env;
};
REGISTER_ZYGISK_MODULE(HXPModule)
